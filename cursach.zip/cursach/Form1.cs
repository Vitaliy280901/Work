﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Security.Cryptography;

namespace cursach
{
    public partial class Авторизация : Form
    {
        private SQLiteConnection db;
        public Авторизация()
        {

            InitializeComponent();
            label1.Text = "Логин";
            label2.Text = "Пароль";
            db = new SQLiteConnection("Data Source = DataBase.db; Version=3");//инициализация бд
            db.Open();
            button1.Text = "Ввод";
            textBox2.PasswordChar = '*';
        }
        
        private void label1_Click(object sender, EventArgs e)
        {

        }
        public string Hash(string input)
        {
            using (SHA1Managed sha1 = new SHA1Managed())
            {
                var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(input));
                var sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                MessageBox.Show("Ошибка! Данные не введены!");
                textBox1.Text = string.Empty;
                textBox2.Text = string.Empty;
            }
            else
            {
                SQLiteCommand CMD = db.CreateCommand();// переменая, которая будет инициировать команды
                CMD.CommandText = "SELECT * FROM users where Login=" + "'" + textBox1.Text + "'" + ";";
                SQLiteCommand CMD2 = db.CreateCommand();
                CMD2.CommandText = "SELECT * FROM users where Password=" + "'" + Hash(textBox2.Text) + "'" + ";";
                if (string.IsNullOrEmpty((string)CMD.ExecuteScalar()))
                {
                    MessageBox.Show("Ошибка! Неверно введены логин или пароль!");
                    textBox1.Text = string.Empty;
                    textBox2.Text = string.Empty;
                }
                else
                {
                    if (string.IsNullOrEmpty((string)CMD2.ExecuteScalar()))
                    {
                        MessageBox.Show("Ошибка! Неверно введены логин или пароль!");
                        textBox1.Text = string.Empty;
                        textBox2.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show("Успешная авторизация! Добро пожаловать!");
                        db.Close();
                        this.Hide();
                        var formMain = new Form2();
                        formMain.Closed += (s, args) => this.Close();
                        formMain.Show();
                    }
                }

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form4 = new Form4();
            form4.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
