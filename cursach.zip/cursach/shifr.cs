﻿using System;
using System.Linq;

namespace cursach
{
    public class shifr  //наследование
    {
        char[,] alphabet = {{'A', 'B', 'C','D','E','F'},
                            {'G','H','I','J','K','L'},
                            { 'M','N','O','P','Q','R'},
                            { 'S','T','U','V','W','X'},
                            { 'Y','Z',',','!','.',':'},
                            { '^','?',';','(',')',' ' }};
        //шифрование текста
        public string Encrypt(string input)//шифруем
        {
            string new_message = "";//зашифрованный текст
           
            var new_check = 0;//проверка на то, что символ текста нашелся в матрице
            for (int k = 0; k < input.Length; k++)//цикл по длине строки
            {
                for (int i = 0; i < 6; i++)//цикл по столбцам матрицы символов 
                {
                    if (new_check == 1) //если символ текста был найден в матрице то выходим
                    {
                        new_check = 0;
                        break;
                        
                    }
                    for (int j = 0; j < 6; j++)//цикл по строкам матрицы символов
                    {
                        if (alphabet[j,i].Equals(Char.ToUpper(input[k])))//проверка элемента матрицы и символа текста
                        {
                            new_message = new_message + Convert.ToString(j) + Convert.ToString(i);//добовляем координаты элементов матрицы 
                            new_check = 1;
                            break;
                            
                        }

                    }
                }
                new_check = 0;
            }


                return new_message;
        }
       
        //расшифровка текста
        public  string Decrypt(string input)
        {
            string new_message = "";
          
            for (int i = 0; i < input.Length; i=i + 2)//цикл по строке зашифрованной
            {
                new_message += Convert.ToString(alphabet.GetValue(
                    Int32.Parse(Convert.ToString(input[i])), Int32.Parse(Convert.ToString(input[i+1])))
                    );//здесь мы ищем элемент по индексам, которыми является зашифрованная строка
            }

            return new_message;
        }
    }
}
