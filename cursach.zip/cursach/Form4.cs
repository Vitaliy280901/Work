﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Security.Cryptography;

namespace cursach
{
    public partial class Form4 : Form
    {
        private SQLiteConnection db;
        public Form4()
        {
            db = new SQLiteConnection("Data Source = DataBase.db; Version=3");//инициализация бд
            db.Open();

            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
        private string Hash(string input)
        {
            using (SHA1Managed sha1 = new SHA1Managed())
            {
                var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(input));
                var sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SQLiteCommand CMD = db.CreateCommand();
            SQLiteCommand CMD2 = db.CreateCommand();
            CMD.CommandText = "select Login From users where Login = '" + textBox1.Text + "';";
            if (!String.IsNullOrWhiteSpace(textBox1.Text) && !String.IsNullOrWhiteSpace(textBox2.Text) && !String.IsNullOrWhiteSpace(textBox3.Text)
                && !String.IsNullOrEmpty(textBox1.Text) && !String.IsNullOrEmpty(textBox2.Text) && !String.IsNullOrEmpty(textBox3.Text))
                if (String.IsNullOrEmpty((string)CMD.ExecuteScalar()))
                {
                    if (textBox2.Text == textBox3.Text)
                    {
                        CMD2.CommandText = "INSERT INTO users (Login,Password) VALUES ('" + textBox1.Text + "','" + Hash(textBox2.Text) + "');";
                        CMD2.ExecuteScalar();
                        MessageBox.Show("Вы зарегистрированны");
                        var form4 = new Авторизация();
                        form4.Show();
                        this.Close();
                    }
                    else MessageBox.Show("Пароли не совпадают");
                }
                else MessageBox.Show("Пользователь с таким логином уже существует");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var form3 = new Авторизация();
            form3.Show();
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
