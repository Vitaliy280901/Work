﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cursach
{
    public partial class about_programm : Form
    {
        public about_programm()
        {
           
            InitializeComponent();
            pictureBox2.Image = Properties.Resources._1;
            label1.Text = "Матрица Полибия =";
            label2.Text = "    Шифр полибия принимает на вход текст, состоящий из символов, указанных \n в матрице Полиби." +
                " На выходе получается строка чисел, которая создана по \n матрице Полибия.";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var form = new Form2();
            form.Show();
            this.Close();
        }

        private void about_programm_Load(object sender, EventArgs e)
        {

        }
    }
}
