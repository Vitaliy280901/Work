﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
 using System.IO;
using System.Text.RegularExpressions;

namespace cursach
{
    public partial class Form2 : Form
    {
        SQLiteConnection db; //инициализация переменной для бд
        OpenFileDialog openFileDialog1 = new OpenFileDialog(); //переменная для открытия 
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();//переменная для сохранения 
        shifr encrypter = new shifr(); //переменная для шифровнания
        private bool check_input(string input, string shifr_type)
        {
            if (shifr_type == "encrypt") //если тип зашифровка
            {
                string pattern = @"[^a-zA-Z||,||!||.||:||^||?||;||(||)|| ]";//проверяем символы
                if (!Regex.IsMatch(input, pattern))// если символы проходят
                {
                    return true;
                }
                else { return false; }
            }
            else if (shifr_type == "decrypt")//если расшифровка
            {
                string pattern = @"\D";
                if (!Regex.IsMatch(input, pattern))
                {
                    if (input.Length % 2 == 0)
                    {
                        return true;
                    }
                    else return false;
                }
                else { return false; }
                
            }
            return true;
        }
        public Form2()
        {
            InitializeComponent();
            db = new SQLiteConnection("Data Source = DataBase.db; Version=3");//открываем связь с бд
            db.Open(); // открываем бд
            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*"; //фильтр для типа файлов
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";

        }

        
        private void Form2_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            textBox2.Visible = false;
            button5.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox3.Text) && !String.IsNullOrWhiteSpace(textBox3.Text) && check_input(textBox3.Text, "decrypt")) //проверка на пустоту и на наличие 
                //недопустимых символов
                textBox1.Text = encrypter.Decrypt(textBox3.Text); //расшифровываем
            else MessageBox.Show("В поле должны быть введены числа без пробела! Кол-во чисел четное");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // получаем выбранный файл
            // читаем файл в строку
            textBox3.Text = File.ReadAllText(openFileDialog1.FileName, Encoding.GetEncoding(1251));
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)//зашифровываем 
        {
            if (!String.IsNullOrEmpty(textBox1.Text) && !String.IsNullOrWhiteSpace(textBox1.Text) && check_input(textBox1.Text, "encrypt"))
                textBox3.Text = encrypter.Encrypt(textBox1.Text);
            else MessageBox.Show("Введены некорректные символы");//инкапсуляция
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try // тут мы сохраняем в файл и в бд зашифрованный файл , если он уже будет, то в бд не занесется
            {
                var CMD = db.CreateCommand();
                CMD.CommandText = "INSERT INTO shifr (encrypt) VALUES "+"("+ "'" + textBox3.Text + "'" + ");"; //запрос  в бд
                CMD.ExecuteNonQuery();//выполняем запрос
                
            }
            catch 
            {
                
            }
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)//сохраняем в файл
                return;
            // получаем выбранный файл
            // сохраняем текст в файл

            System.IO.File.WriteAllText(saveFileDialog1.FileName, textBox3.Text, Encoding.GetEncoding(1251));

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

      

        private void button1_Click(object sender, EventArgs e) // тут мы все зашифрованный тексты выводим в окно
        {
            label2.Visible = true;
            textBox2.Visible = true;
            button5.Visible = true;
            richTextBox1.Clear();
            var CMD = db.CreateCommand();
            var CMD2 = db.CreateCommand();//переменные для хранения команд
            CMD.CommandText = "SELECT id FROM shifr WHERE id = (select max(id) from shifr) ;"; //команда для определения последнего элемента таблицы

            int count_row = Convert.ToInt32(CMD.ExecuteScalar());//тут мы выполняем запрос 

            for (int i = 1; i <= count_row; i++)//тут через цикл мы выводим все строки
            {
                CMD2.CommandText = "SELECT encrypt FROM shifr WHERE id =" +Convert.ToString(i)+";";
                string str = Convert.ToString(CMD2.ExecuteScalar());
                    if (str !="")
                richTextBox1.Text += "[" + Convert.ToString(i) + "] \n" + str  +"\n";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)// тут мы обрабатываем ввод числа, который присвоен к зашифрованной строке
        {
            try
            {
                int check = Convert.ToInt32(textBox2.Text);
            }
            catch{ MessageBox.Show("Введено не целочисленное число"); textBox2.Clear(); }
            if (!String.IsNullOrEmpty(textBox2.Text))
            {
                var CMD = db.CreateCommand();
                CMD.CommandText = "SELECT encrypt FROM shifr WHERE id =" + textBox2.Text + ";";
                textBox3.Text = Convert.ToString(CMD.ExecuteScalar());
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form = new about_programm();
            form.Show();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            Application.Exit();
        }
    }
}
